
dofile_once("data/scripts/lib/utilities.lua")
local MATCHES = { "/boss_alchemist/", "/boss_pit/", "/parallel/alchemist/parallel_alchemist.xml", "/parallel/tentacles/parallel_tentacles.xml" }
local function hits(path)
  if not path then return false end
  for _,m in ipairs(MATCHES) do
    if string.find(path, m, 1, true) then return true end
  end
  return false
end
function WTW_OnEntitySpawned(eid)
  if eid == nil or eid == 0 then return end
  local path = EntityGetFilename(eid) or ""
  if not hits(path) then return end
  if EntityHasTag(eid, "wtw_guardian_hooked") then return end
  EntityAddTag(eid, "wtw_guardian_hooked")
  EntityAddComponent2(eid, "LuaComponent", {
    script_death = "mods/worldteleportspell/files/scripts/guardian_drop_on_death.lua",
    remove_after_executed = true,
  })
end
