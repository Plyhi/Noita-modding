dofile_once("data/scripts/lib/utilities.lua")
local eid = GetUpdatedEntityID()
local x, y, rot = EntityGetTransform(eid)

local vx = math.cos(rot)
local vy = math.sin(rot)
local len = math.sqrt(vx*vx + vy*vy); if len < 0.0001 then len = 1 end
vx = vx/len; vy = vy/len

local dirs = {
    { 1,  0},  -- E
    { 1, -1},  -- NE
    { 0, -1},  -- N
    {-1, -1},  -- NW
    {-1,  0},  -- W
    {-1,  1},  -- SW
    { 0,  1},  -- S
    { 1,  1},  -- SE
}
local best_dx, best_dy, best_dot = 1,0, -999
for i=1,#dirs do
    local dx, dy = dirs[i][1], dirs[i][2]
    local dlen = math.sqrt(dx*dx + dy*dy); dx = dx/dlen; dy = dy/dlen
    local dot = vx*dx + vy*dy
    if dot > best_dot then best_dot = dot; best_dx, best_dy = dx, dy end
end

local function setf(name, v)
    local comps = EntityGetComponentIncludingDisabled(eid, "VariableStorageComponent") or {}
    for _,c in ipairs(comps) do if ComponentGetValue2(c, "name")==name then ComponentSetValue2(c, "value_float", v) end end
end
setf("wtp_ox", x); setf("wtp_oy", y); setf("wtp_dx", best_dx); setf("wtp_dy", best_dy)

local vcomp = EntityGetFirstComponentIncludingDisabled(eid, "VelocityComponent")
if vcomp ~= nil then ComponentSetValue2(vcomp, "mVelocity", 0.0, 0.0) end
