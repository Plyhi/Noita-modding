dofile_once("data/scripts/lib/utilities.lua")
local eid = GetUpdatedEntityID()

local function getf(name, default)
    local comps = EntityGetComponentIncludingDisabled(eid, "VariableStorageComponent") or {}
    for _,c in ipairs(comps) do if ComponentGetValue2(c, "name")==name then return ComponentGetValue2(c, "value_float") end end
    return default
end

local ox, oy = getf("wtp_ox", 0), getf("wtp_oy", 0)
local dx, dy = getf("wtp_dx", 1), getf("wtp_dy", 0)
local tx, ty = ox + dx*35840, oy + dy*35840

local players = EntityGetWithTag("player_unit") or {}
local player = players[1] or 0
if player ~= 0 and EntityGetIsAlive(player) then
    EntitySetTransform(player, tx, ty)
    local v = EntityGetFirstComponentIncludingDisabled(player, "VelocityComponent")
    if v ~= nil then ComponentSetValue2(v, "mVelocity", 0.0, 0.0) end
end
