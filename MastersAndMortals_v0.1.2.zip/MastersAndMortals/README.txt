Masters & Mortals (v0.1.2)
--------------------------
Entrance-anchored placement: set DESIRED_DX/DY to decide where the **door** goes relative to player spawn.

Tweak guide:
- Move the door horizontally: change DESIRED_DX (negative = left of spawn).
- Move the door vertically: change DESIRED_DY (negative = above spawn).
- If your build's temple art differs a bit, nudge ENTRANCE_FROM_TL_X/Y in steps of ~16 px.

Debug:
- On spawn, you get a banner with both the top-left and the computed entrance coordinates.
- A sign marks the top-left; a lantern marks the entrance.
