-- Masters & Mortals — Step 1 (v0.1.3)
-- Entrance anchored. Door placed exactly at the player's spawn (DESIRED_DX/DY = 0,0).

-- === CONFIG ===
local DESIRED_DX = 0     -- entrance horizontally at player
local DESIRED_DY = 0     -- entrance vertically at player

-- Offset from temple.png TOP-LEFT to the entrance (lantern doorway). Adjust if art differs.
local ENTRANCE_FROM_TL_X = 560
local ENTRANCE_FROM_TL_Y = 360

local function already_spawned()
    return GlobalsGetValue("mam_step1_temple_spawned", "0") == "1"
end

local function mark_spawned()
    GlobalsSetValue("mam_step1_temple_spawned", "1")
end

local function place_markers(px, py, ex, ey)
    pcall(function()
        EntityLoad("data/entities/props/sign_post.xml", px + 16, py + 140)       -- top-left marker
        EntityLoad("data/entities/props/temple_lantern.xml", ex, ey + 8)         -- entrance marker
    end)
end

local function try_spawn_temple(x, y)
    local base    = "data/biome_impl/temple/temple.png"
    local visual  = "data/biome_impl/temple/temple_visual.png"
    local back    = "data/biome_impl/temple/temple_background.png"

    local entrance_target_x = x + DESIRED_DX
    local entrance_target_y = y + DESIRED_DY
    local px = entrance_target_x - ENTRANCE_FROM_TL_X
    local py = entrance_target_y - ENTRANCE_FROM_TL_Y

    LoadPixelScene(base, visual, px, py, back, true)

    local ex = px + ENTRANCE_FROM_TL_X
    local ey = py + ENTRANCE_FROM_TL_Y

    if GamePrintImportant ~= nil then
        GamePrintImportant("Masters & Mortals",
            string.format("Placed: top-left %d,%d  entrance %d,%d", px, py, ex, ey))
    end

    GlobalsSetValue("mam_last_temple_px", tostring(px))
    GlobalsSetValue("mam_last_temple_py", tostring(py))
    GlobalsSetValue("mam_last_temple_ex", tostring(ex))
    GlobalsSetValue("mam_last_temple_ey", tostring(ey))

    place_markers(px, py, ex, ey)
end

function OnPlayerSpawned(player_entity)
    if already_spawned() then return end
    local x, y = EntityGetTransform(player_entity)
    if x ~= nil and y ~= nil then
        try_spawn_temple(x, y)
        mark_spawned()
    end
end
