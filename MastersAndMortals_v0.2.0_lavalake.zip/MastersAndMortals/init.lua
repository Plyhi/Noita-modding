-- Masters & Mortals — v0.2.0
-- Entrance anchored to the **left edge of the lava lake** (zone 1 end), using constants inspired by Anvil of Destiny.
-- You can nudge the final door position via ENTRANCE_OFFSET_* without worrying about the temple's top-left.

-- === LAVA LAKE EDGE (constants tuned for vanilla) ===
local LAVA_LAKE_LEFT_X   = 1536   -- approximate left edge x where lava lake area begins
local LAVA_LAKE_SURFACE_Y= 924    -- approximate surface y used by Anvil of Destiny injection

-- === ENTRANCE offsets relative to the lake edge reference ===
local ENTRANCE_OFFSET_X = -64     -- put door slightly left of the edge by default
local ENTRANCE_OFFSET_Y = -40     -- small vertical nudge

-- === Temple internals: entrance offset from top-left of temple pixel scene ===
local ENTRANCE_FROM_TL_X = 560
local ENTRANCE_FROM_TL_Y = 360

local function already_spawned()
    return GlobalsGetValue("mam_step1_temple_spawned", "0") == "1"
end

local function mark_spawned()
    GlobalsSetValue("mam_step1_temple_spawned", "1")
end

local function place_markers(px, py, ex, ey)
    pcall(function()
        EntityLoad("data/entities/props/sign_post.xml", px + 16, py + 140)       -- top-left marker
        EntityLoad("data/entities/props/temple_lantern.xml", ex, ey + 8)         -- entrance marker
    end)
end

local function try_spawn_by_lavalake()
    local base    = "data/biome_impl/temple/temple.png"
    local visual  = "data/biome_impl/temple/temple_visual.png"
    local back    = "data/biome_impl/temple/temple_background.png"

    local entrance_target_x = LAVA_LAKE_LEFT_X + ENTRANCE_OFFSET_X
    local entrance_target_y = LAVA_LAKE_SURFACE_Y + ENTRANCE_OFFSET_Y

    local px = entrance_target_x - ENTRANCE_FROM_TL_X
    local py = entrance_target_y - ENTRANCE_FROM_TL_Y

    LoadPixelScene(base, visual, px, py, back, true)

    local ex = px + ENTRANCE_FROM_TL_X
    local ey = py + ENTRANCE_FROM_TL_Y

    if GamePrintImportant then
        GamePrintImportant("Masters & Mortals", string.format("Lava-lake entrance at %d,%d  (top-left %d,%d)", ex, ey, px, py))
    end
    GlobalsSetValue("mam_last_temple_px", tostring(px))
    GlobalsSetValue("mam_last_temple_py", tostring(py))
    GlobalsSetValue("mam_last_temple_ex", tostring(ex))
    GlobalsSetValue("mam_last_temple_ey", tostring(ey))

    place_markers(px, py, ex, ey)
end

function OnPlayerSpawned(player_entity)
    if already_spawned() then return end
    try_spawn_by_lavalake()
    mark_spawned()
end
