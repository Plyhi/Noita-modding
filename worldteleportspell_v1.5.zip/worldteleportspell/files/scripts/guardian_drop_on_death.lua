
dofile_once("data/scripts/gun/gun_actions.lua")
local eid = GetUpdatedEntityID()
local x, y = EntityGetTransform(eid)
if CreateItemActionEntity ~= nil then
  CreateItemActionEntity("WORLD_TELEPORT_SPELL", x, y)
end
