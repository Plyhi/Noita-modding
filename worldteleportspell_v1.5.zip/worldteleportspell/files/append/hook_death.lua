
local eid = GetUpdatedEntityID and GetUpdatedEntityID() or 0
if eid ~= 0 and not EntityHasTag(eid, "wtw_guardian_hooked") then
  EntityAddTag(eid, "wtw_guardian_hooked")
  EntityAddComponent2(eid, "LuaComponent", {
    script_death = "mods/worldteleportspell/files/scripts/guardian_drop_on_death.lua",
    remove_after_executed = true,
  })
end
