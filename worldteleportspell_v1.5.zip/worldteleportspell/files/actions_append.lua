table.insert(actions,
{
    id          = "WORLD_TELEPORT_SPELL",
    name        = "World Teleport Spell",
    description = "Snaps to 8 directions (N, NE, E, SE, S, SW, W, NW). After ~1s, you teleport one world length along that direction — ideal for parallel world travel.",
    sprite      = "mods/worldteleportspell/files/ui_gfx/gun_actions/world_teleport_spell.png",
    type        = ACTION_TYPE_UTILITY,
    spawn_level = "",
    spawn_probability = "0",
    price       = 240,
    mana        = 35,
    max_uses    = -1,
    action      = function()
        add_projectile("mods/worldteleportspell/files/entities/world_tp_marker.xml")
        c.fire_rate_wait = c.fire_rate_wait + 5
        shot_effects.recoil_knockback = shot_effects.recoil_knockback + 3.0
    end,
})
