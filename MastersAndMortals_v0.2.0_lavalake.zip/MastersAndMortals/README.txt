Masters & Mortals (v0.2.0) — Lava Lake Anchor
----------------------------------------------
The Holy Mountain clone is placed with its **entrance** aligned to the **left edge of the lava lake** (end of Zone 1).

Tweak:
- Adjust ENTRANCE_OFFSET_X/Y to move the **door** relative to the lake edge (defaults: -64, -40).
- If your temple art differs, nudge ENTRANCE_FROM_TL_X/Y in ~16px steps.
- If your worldgen differs a lot, adjust LAVA_LAKE_LEFT_X / LAVA_LAKE_SURFACE_Y (defaults 1536 / 924).

Debug:
- The game prints both **entrance** and **top-left** coordinates and drops markers (sign=top-left, lantern=entrance).
