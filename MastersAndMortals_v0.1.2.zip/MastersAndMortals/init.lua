-- Masters & Mortals — Step 1 (v0.1.2)
-- Places the Holy Mountain so that its ENTRANCE is positioned at a desired offset from the player's spawn.
-- Internally, the temple pixel scene's origin is its TOP-LEFT. The entrance is some pixels inside the image.
-- We compensate with ENTRANCE_FROM_TL_* so that you think in "where do I want the door?" instead of image corner.

-- === CONFIG (think in 'door placement' terms) ===
local DESIRED_DX = -3200  -- put entrance ~100m left of player
local DESIRED_DY = -40    -- small vertical nudge

-- Approximate offset from TOP-LEFT of temple.png to the ENTRANCE location (tune if needed)
-- These numbers make the visible doorway land where you expect. Adjust in steps of ~16px if off in your build.
local ENTRANCE_FROM_TL_X = 560
local ENTRANCE_FROM_TL_Y = 360

local function already_spawned()
    return GlobalsGetValue("mam_step1_temple_spawned", "0") == "1"
end

local function mark_spawned()
    GlobalsSetValue("mam_step1_temple_spawned", "1")
end

local function place_markers(px, py, ex, ey)
    -- Visual helpers: top-left marker (sign) and entrance marker (lantern)
    pcall(function()
        EntityLoad("data/entities/props/sign_post.xml", px + 16, py + 140)            -- top-left marker
        EntityLoad("data/entities/props/temple_lantern.xml", ex, ey + 8)              -- entrance marker
    end)
end

local function try_spawn_temple(x, y)
    local base    = "data/biome_impl/temple/temple.png"
    local visual  = "data/biome_impl/temple/temple_visual.png"
    local back    = "data/biome_impl/temple/temple_background.png"

    -- Compute top-left so that (entrance) ends up at (player + desired offset)
    local entrance_target_x = x + DESIRED_DX
    local entrance_target_y = y + DESIRED_DY
    local px = entrance_target_x - ENTRANCE_FROM_TL_X
    local py = entrance_target_y - ENTRANCE_FROM_TL_Y

    LoadPixelScene(base, visual, px, py, back, true)

    -- Derived entrance coords (for display + marker)
    local ex = px + ENTRANCE_FROM_TL_X
    local ey = py + ENTRANCE_FROM_TL_Y

    -- Debug banner
    if GamePrintImportant ~= nil then
        GamePrintImportant("Masters & Mortals",
            string.format("Temple top-left: %d, %d  |  entrance: %d, %d", px, py, ex, ey))
    else
        GamePrint(string.format("[M&M] top-left: %d, %d  entrance: %d, %d", px, py, ex, ey))
    end

    GlobalsSetValue("mam_last_temple_px", tostring(px))
    GlobalsSetValue("mam_last_temple_py", tostring(py))
    GlobalsSetValue("mam_last_temple_ex", tostring(ex))
    GlobalsSetValue("mam_last_temple_ey", tostring(ey))

    place_markers(px, py, ex, ey)
end

function OnPlayerSpawned(player_entity)
    if already_spawned() then return end
    local x, y = EntityGetTransform(player_entity)
    if x ~= nil and y ~= nil then
        try_spawn_temple(x, y)
        mark_spawned()
    end
end
