Masters & Mortals (v0.1) — Step 1
----------------------------------
Spawns a Holy Mountain-style room to the left of the player's start.

Tuning:
- Edit OFFSET_X / OFFSET_Y at the top of init.lua to move the room.

Notes:
- This is the foundation for the tutorial room. No perk/shop changes yet.
- Next steps will replace the shop with basic spell stock and add the Grand Mage room.
