-- Masters & Mortals — Step 1 (v0.1.1 debug)
-- Spawns a Holy Mountain-like pixel scene to the left of the player's starting position,
-- and drops a lantern + sign where the TOP-LEFT corner of the pixel scene is placed.

-- === CONFIG ===
local OFFSET_X = -3200   -- negative: left of spawn
local OFFSET_Y = -180    -- small lift

local function already_spawned()
    return GlobalsGetValue("mam_step1_temple_spawned", "0") == "1"
end

local function mark_spawned()
    GlobalsSetValue("mam_step1_temple_spawned", "1")
end

local function try_spawn_temple_near(x, y)
    local base    = "data/biome_impl/temple/temple.png"
    local visual  = "data/biome_impl/temple/temple_visual.png"
    local back    = "data/biome_impl/temple/temple_background.png"

    local px = x + OFFSET_X
    local py = y + OFFSET_Y

    if GamePrintImportant ~= nil then
        GamePrintImportant("Masters & Mortals", string.format("Temple placed at: %d, %d (top-left)", px, py))
    else
        GamePrint(string.format("[M&M] Temple placed at: %d, %d (top-left)", px, py))
    end
    GlobalsSetValue("mam_last_temple_px", tostring(px))
    GlobalsSetValue("mam_last_temple_py", tostring(py))

    LoadPixelScene(base, visual, px, py, back, true)

    pcall(function()
        EntityLoad("data/entities/props/temple_lantern.xml", px + 48, py + 140)
        EntityLoad("data/entities/props/sign_post.xml", px + 16, py + 140)
    end)
end

function OnPlayerSpawned(player_entity)
    if already_spawned() then return end
    local x, y = EntityGetTransform(player_entity)
    if x ~= nil and y ~= nil then
        try_spawn_temple_near(x, y)
        mark_spawned()
    end
end
