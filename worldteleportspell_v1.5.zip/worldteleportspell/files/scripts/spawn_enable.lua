
dofile_once("data/scripts/gun/gun_actions.lua")
local function is_unlocked()
  return HasFlagPersistent("wtw_unlocked") or (ModSettingGet("worldteleportspell.unlocked_temp") == true)
end
function enable_worldteleport_spawn_if_unlocked()
  if not is_unlocked() then return end
  for i,v in ipairs(actions) do
    if v.id == "WORLD_TELEPORT_SPELL" then
      v.spawn_level = "2,3,4,5,6"
      v.spawn_probability = "0.6,0.6,0.6,0.6,0.6"
      v.price = v.price or 240
      break
    end
  end
end
