ModLuaFileAppend("data/entities/animals/boss_pit/boss_pit_logic.lua", "mods/worldteleportspell/files/append/hook_death.lua")
ModLuaFileAppend("data/entities/animals/boss_alchemist/init.lua", "mods/worldteleportspell/files/append/hook_death.lua")

ModLuaFileAppend("data/scripts/gun/gun_actions.lua", "mods/worldteleportspell/files/actions_append.lua")

function OnEntitySpawned(entity_id)
  dofile_once("mods/worldteleportspell/files/scripts/guardian_watch.lua")
  if WTW_OnEntitySpawned then WTW_OnEntitySpawned(entity_id) end
end

function OnPlayerSpawned(player_entity)
  dofile_once("mods/worldteleportspell/files/starting_item.lua")
  if OnPlayerSpawned then OnPlayerSpawned(player_entity) end
end

function OnModInitialized()
  if ModSettingGet("worldteleportspell.unlocked_temp") == true and not HasFlagPersistent("wtw_unlocked") then
    AddFlagPersistent("wtw_unlocked")
  end
end
