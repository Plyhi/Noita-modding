
function OnPlayerSpawned(player_entity)
    local dbg = ModSettingGet("worldteleportspell.debug")
    if dbg == nil then dbg = true end
    if dbg == true then
        local x, y = EntityGetTransform(player_entity)
        local card = CreateItemActionEntity("WORLD_TELEPORT_SPELL", x, y)
        if card ~= nil then GamePickUpInventoryItem(player_entity, card, false) end
    end
    dofile_once("mods/worldteleportspell/files/scripts/spawn_enable.lua")
    if enable_worldteleport_spawn_if_unlocked then enable_worldteleport_spawn_if_unlocked() end
end
