-- Masters & Mortals — Step 1
-- Spawns a Holy Mountain-like pixel scene to the left of the player's starting position.

-- === CONFIG ===
-- World coordinates are pixels. 3200 px ~= "about 100 m" left in our shorthand.
local OFFSET_X = -3200   -- negative: left of spawn
local OFFSET_Y = -180    -- small lift to prevent burying the door

local function already_spawned()
    return GlobalsGetValue("mam_step1_temple_spawned", "0") == "1"
end

local function mark_spawned()
    GlobalsSetValue("mam_step1_temple_spawned", "1")
end

local function try_spawn_temple_near(x, y)
    -- Stock Holy Mountain pixel scene assets.
    local base    = "data/biome_impl/temple/temple.png"
    local visual  = "data/biome_impl/temple/temple_visual.png"
    local back    = "data/biome_impl/temple/temple_background.png"

    -- placement
    local px = x + OFFSET_X
    local py = y + OFFSET_Y

    -- Load the pixel scene; 'true' marks it unique so it won't duplicate on reloads.
    -- Signature: LoadPixelScene(material_png, visual_png, pos_x, pos_y, background_png, is_unique)
    LoadPixelScene(base, visual, px, py, back, true)
end

function OnPlayerSpawned(player_entity)
    if already_spawned() then return end
    local x, y = EntityGetTransform(player_entity)
    if x ~= nil and y ~= nil then
        try_spawn_temple_near(x, y)
        mark_spawned()
    end
end
