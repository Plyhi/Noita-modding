
dofile_once("data/scripts/lib/mod_settings.lua")
local mod_id = "worldteleportspell"
local function get_id(key) return mod_id .. "." .. key end
local mod_settings = {
  { id=get_id("debug"), ui_name="Debug: auto-give spell at start", ui_description="ON = receive the card at spawn (dev/test). OFF = guardians drop it.", value_default=true, scope=MOD_SETTING_SCOPE_RUNTIME },
  { id=get_id("unlocked_temp"), ui_name="Unlocked (temporary)", ui_description="Treat as unlocked so it rolls in shops/wands. Will be replaced by a mission later.", value_default=true, scope=MOD_SETTING_SCOPE_NEW_GAME },
}
function ModSettingsUpdate(init_scope) mod_settings_update(mod_id, mod_settings, init_scope) end
function ModSettingsGuiCount() return mod_settings_gui_count(mod_id, mod_settings) end
function ModSettingsGui(gui, in_main_menu) mod_settings_gui(mod_id, mod_settings, gui, in_main_menu) end
