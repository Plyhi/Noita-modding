Masters & Mortals (v0.1.3)
--------------------------
Entrance exactly on player spawn (DESIRED_DX/DY = 0,0).
If the doorway is a bit off in your build, tweak ENTRANCE_FROM_TL_X/Y in ~16 px steps.
Markers: sign at top-left, lantern at entrance.
