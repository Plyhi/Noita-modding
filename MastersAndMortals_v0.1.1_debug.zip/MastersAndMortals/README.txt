Masters & Mortals (v0.1) — Step 1
Spawns a Holy Mountain-style room to the left of the player's start.

v0.1.1: prints placement coords and drops lantern+sign marker at the pixel scene top-left.
